%% Contextual Correlation Preserving Multi-View Featured Graph Clustering

function [cluster_number] = CCPMVFGC(K,path,numView)
% A Matlab implementation of the graph clustering framework, dubbed
% Contextual Correlation Preserving Multi-View Featured Graph Clustering
% (CCPMVFGC), which is published in IEEE Transactions on Cybernetics, DOI: 10.1109/TCYB.2019.2926431, 2019.
%% Basic information on CCPMVFGC
% K: The number of Clusters;
% Max_Iter max number of iterations. Default: 400;
% interval: The interval of iterations allows CCPMVFGC to display value of
% the objective function. Default: 100;
% path: directory of the graph data;
% alpha, lambda: model parameters as what are introduced in the paper.
% numView: Total number of views of vertex features.
% Example of running CCPMVFGC: Single view of vertex features:
% CCPMVFGC(4,1,1,'syn1k',1);
% Multi-view of vertex features: CCPMVFGC(4,1,1,'multi-syn1k',2). The exemplified
% datasets are provided. Users may process their graph data according to
% the format used by the exemplified datasets.

%% Loading graph data
fprintf('Loading network data...\n');

[Y,F,X] = Load_Data(path,numView,1);

%default setting
alpha =5;
lambda = 1;

Max_Iter = 400;
interval = 100;

fullrandom = 0;


N = size(Y,1);
Para.Y = Y;
Para.F = F;
Para.X = X;
Para.V = rand(N,K);

if(fullrandom==1)
    for i = 1 : numView
        U{i} = rand(size(F{i},1),K);
    end
    Para.U = U;
end



Para.K = K;
Para.Max_Iter = Max_Iter;
Para.alpha = alpha;

Para.lambda = lambda;

Para.interval = interval;
Mini_Gap = 1e-5*interval;
Para.Mini_Gap = Mini_Gap;

%% Model optimization
[Result] = Model_Optimization(Para);

fprintf('Model Optimization is done, writing info on the learned model...\n');


%% Output learned latent spaces and log data

path = strcat('.\',path,'\');

prefix=strcat('K=',num2str(K));

dlmwrite(strcat(path,prefix,'_V'),Result.V);
for i = 1:numView
dlmwrite(strcat(path,prefix,'_U_',num2str(i)),Result.U{i});
end


fid = fopen(strcat(path,prefix,'.log'), 'w');
fprintf(fid, 'Parameters setting:\n');
fprintf(fid, 'K = %s\tAlpha=%s\tlambda = %s\tMini_Gap = %s\tMax_Iter = %s\n',num2str(K),num2str(alpha),num2str(lambda),num2str(Mini_Gap),num2str(Max_Iter));
fprintf(fid, 'The number of iterations: %s\n', num2str(Result.loop));
fprintf(fid, 'Optimization Time: %s\n', num2str(Result.time));
fprintf(fid, 'Time consumption per iteration: %s\n', num2str(Result.time/Result.loop));
fprintf(fid, 'Objective values:\n');

for i=1:size(Result.Objective,2)
    fprintf(fid, '%s\t', num2str(Result.Objective(1,i)));
end
fclose(fid);

%% Extract graph clusters
fprintf('Identifying clusters...\n');

cluster_number = Identify_Cluster_Base(Result.V,path);

fprintf('Job Done!\n');

end
